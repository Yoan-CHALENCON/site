import numpy as np
from copy import deepcopy

matrice_base = [
            [0,1,0,0,0,0,0,0,0,0],
            [0,0,1,0,0,0,0,0,0,0],
            [1,1,1,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0]]

def verif(y,x):
    xmin = 0
    ymin = 0
    ymax = len(matrice)
    xmax = len(matrice[0])
    if y >= ymin and y < ymax and x >= xmin and x < xmax:
        return True
    else:
        return False

def compt(y,x):
    vivantes = 0
    if verif(y-1,x-1) == True and matrice[y-1][x-1] == 1:
        vivantes += 1

    if verif(y-1,x) == True and matrice[y-1][x] == 1:
        vivantes += 1

    if verif(y-1,x+1) == True and matrice[y-1][x+1] == 1:
        vivantes += 1

    if verif(y,x+1) == True and matrice[y][x+1] == 1:
        vivantes += 1

    if verif(y+1,x+1) == True and matrice[y+1][x+1] == 1:
        vivantes += 1

    if verif(y+1,x) == True and matrice[y+1][x] == 1:
        vivantes += 1

    if verif(y+1,x-1) == True and matrice[y+1][x-1] == 1:
        vivantes += 1

    if verif(y,x-1) == True and matrice[y][x-1] == 1:
        vivantes += 1

    return vivantes

for i in range(10):
    matrice = deepcopy(matrice_base)

    for y in range(len(matrice)):
        for x in range(len(matrice[i])):
            if matrice[y][x] == 0:
                if compt(y,x) == 3:
                    matrice_base[y][x] = 1
            else:
                if compt(y,x) == 3 or compt(y,x) == 2:
                    matrice_base[y][x] = 1
                else:
                    matrice_base[y][x] = 0

    print(np.array(matrice_base),"\n")