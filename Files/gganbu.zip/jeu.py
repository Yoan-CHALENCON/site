import random

billes_joueur = 10
billes_main_joueur = 0
pari_joueur = ""

billes_ordi = 10
billes_main_ordi = 0
pari_ordi = ""

result = None
liste_pair_ou_pas = ["pair","impair"]

victoire = None

def echange(bmj, bmo, g):
    if g == True:
        if player == 0:
            if bmo < bmj:
                print("L'ordinateur a bien deviné, il récupère donc", bmo, "bille(s).")
                return(billes_ordi + bmo)
            else:
                print("L'ordinateur a bien deviné, il récupère donc", bmj, "bille(s).")
                return(billes_ordi + bmj)
        if player == 1:
            if bmo < bmj:
                print("Tu as bien deviné, tu récupères donc", bmo, "bille(s).")
                return(billes_joueur + bmo)
            else:
                print("Tu as bien deviné, tu récupères donc", bmj, "bille(s).")
                return(billes_joueur + bmj)
    if g == False:
        if player == 0:
            if bmo < bmj:
                print("L'ordinateur a mal deviné, tu récupères donc", bmo, "bille(s).")
                return(billes_joueur + bmo)
            else:
                print("L'ordinateur a mal deviné, tu récupères donc", bmj, "bille(s).")
                return(billes_joueur + bmj)
        if player == 1:
            if bmo < bmj:
                print("Tu as mal deviné, il récupère donc", bmo, "bille(s).")
                return(billes_ordi + bmo)
            else:
                print("Tu as mal deviné, il récupère donc", bmj, "bille(s).")
                return(billes_ordi + bmj)

player = random.randint(0, 1)

while billes_joueur != 0 and billes_ordi != 0 :
    if player == 0:
        while billes_main_joueur == 0 or billes_main_joueur > billes_joueur:
            billes_main_joueur = int(input("Combien de bille(s) veux - tu mettre dans ta main pour les faire deviner à l'ordi ? "))
            if billes_main_joueur > billes_joueur:
                print("Tu n'as pas assez de bille pour en mettre autant dans ta main !")
        billes_main_ordi = random.randint(1,billes_ordi)
        pari_ordi = random.choice(liste_pair_ou_pas)
        print("L'ordi a parié que tu avais mis un nombre", pari_ordi, "de bille(s) dans ta main.")
        if pari_ordi == "pair":
            if billes_main_joueur % 2 == 0:
                result = True
                billes_ordi = echange(billes_main_joueur, billes_main_ordi, result)
                billes_joueur = 20 - billes_ordi
            else:
                result = False
                billes_joueur = echange(billes_main_joueur, billes_main_ordi, result)
                billes_ordi = 20 - billes_joueur
        if pari_ordi == "impair":
            if billes_main_joueur % 2 != 0:
                result = True
                billes_ordi = echange(billes_main_joueur, billes_main_ordi, result)
                billes_joueur = 20 - billes_ordi
            else:
                result = False
                billes_joueur = echange(billes_main_joueur, billes_main_ordi, result)
                billes_ordi = 20 - billes_joueur
    if player == 1:
        billes_main_ordi = random.randint(1,billes_ordi)
        while pari_joueur != "pair" and pari_joueur != "impair":
                    pari_joueur = str(input("Selon toi, le nombre de bille(s) dans la main de l'ordinateur est - il pair ou impair ? "))
        while billes_main_joueur == 0 or billes_main_joueur > billes_joueur:
            billes_main_joueur = int(input("Combien de bille(s) veux - tu parier ? "))
            if billes_main_joueur > billes_joueur:
                print("Tu n'as pas assez de bille pour en mettre autant dans ta main !")
        if pari_joueur == "pair":
            if billes_main_ordi % 2 == 0:
                result = True
                billes_joueur = echange(billes_main_joueur, billes_main_ordi, result)
                billes_ordi = 20 - billes_joueur
            else:
                result = False
                billes_ordi = echange(billes_main_joueur, billes_main_ordi, result)
                billes_joueur = 20 - billes_ordi
        if pari_joueur == "impair":
            if billes_main_ordi % 2 != 0:
                result = True
                billes_joueur = echange(billes_main_joueur, billes_main_ordi, result)
                billes_ordi = 20 - billes_joueur
            else:
                result = False
                billes_ordi = echange(billes_main_joueur, billes_main_ordi, result)
                billes_joueur = 20 - billes_ordi
    if player == 0:
        player = 1
    else:
        player = 0
    billes_main_joueur = 0
    billes_main_ordi = 0
    pari_joueur = ""
    pari_ordi = ""
    print("Il te reste", billes_joueur, "bille(s).")
if billes_joueur < billes_ordi:
    victoire = "l'ordinateur..."
else:
    victoire = "toi !"
print("La partie est terminée, le gagnant est", victoire)