import random       #importation de random

fichier = open("liste.txt", "r")
donnees = fichier.readlines()
fichier.close()
table = []                            #ouverture de la liste de tous les mots
for element in donnees:
    element = element.rstrip("\n")
    table.append(element)

rejouer = "oui"                    #initialisation de la variable rejouer (à "oui" de base)
score_partie = 11                  #initialisation du score de la partie (à 11 de base)
score_total = 0                    #initialisation du score total (à 0 de base)

while rejouer == "oui":
    score_partie = 11
    mot = random.choice(table)       #choix du mot dans la liste
    mot = mot.lower()       #mise en miniscule du mot
    alphabet = ['a', 'à', 'â', 'ä', 'b', 'c', 'ç', 'd', 'e', 'é', 'è', 'ê', 'ë', 'f', 'g', 'h', 'i', 'î', 'ï', 'j', 'k', 'l', 'm', 'n', 'o', 'ô', 'ö', 'p', 'q', 'r', 's', 't', 'u', 'ù', 'û', 'ü', 'v', 'w', 'x', 'y', 'ÿ', 'z', '-', ' ', "'"]
    reponse = []       #liste contenant les tirets qui seront remplacés par les lettres correctes
    reponse_a_trouvee = []        #mot a trouver sous forme de liste
    compteur_erreurs = 0         #initialisation des variables / listes
    lettre_incorrectes = []       #liste de lettres fausses
    lettres_trouvees = 0       #nb de lettres trouvées
    for lettre in mot:
        reponse.append('_')       #chaque lettre du mot est remplacée par un tiret
        reponse_a_trouvee.append(lettre)       #liste avec le mot à trouver

    def affichage(reponse):
        affichage = ""
        for chose in reponse:
            affichage = affichage + chose + " "
        return affichage

    def faux(lettre_incorrectes):
        faux = ""
        for chose in lettre_incorrectes:
            faux = faux + chose + " "
        return faux

    def dessin(compteur_erreurs):
        if compteur_erreurs == 1:
            print('__')
        elif compteur_erreurs == 2:
            print(' |\n |\n |\n |\n_|_')
        elif compteur_erreurs == 3:
            print('  ___\n |\n |\n |\n |\n_|_')
        elif compteur_erreurs == 4:
            print('  ___\n |/\n |\n |\n |\n_|_')
        elif compteur_erreurs == 5:
            print('  ___\n |/ |\n |\n |\n |\n_|_')
        elif compteur_erreurs == 6:
            print('  ___\n |/ |\n |  0\n |\n |\n_|_')
        elif compteur_erreurs == 7:
            print('  ___\n |/ |\n |  0\n | / \n |\n_|_')
        elif compteur_erreurs == 8:
            print('  ___\n |/ |\n |  0\n | /| \n |\n_|_')
        elif compteur_erreurs == 9:
            print('  ___\n |/ |\n |  0\n | /|\ \n |\n |\n_|_')
        elif compteur_erreurs == 10:
            print('  ___\n |/ |\n |  0\n | /|\ \n | /\n_|_')
        elif compteur_erreurs == 11:
            print('  ___\n |/ |\n |  0\n | /|\ \n | / \ \n_|_')

    print("C'est parti ! 😜\n⚠Attention, les espaces, les tirets, les apostrophes, les cédilles et les accents peuvent être dans le mot qu'il faut trouver.\nBonne chance ! 👍")
    print("Le mot contient", len(mot), "caractères.")
    print(affichage(reponse))
    while reponse_a_trouvee != reponse and compteur_erreurs < 11:       #tant que mot pas trouvé et moins de 11 erreurs
        proposition = str(input("Propose un caractère ou un mot : "))       #demande la lettre / le mot
        lettre_proposee = proposition.lower()                           #mise en miniscule de la prop
        if lettre_proposee in alphabet or lettre_proposee == mot:       #si prop est lettre dans alphabet ou égal au mot
            if lettre_proposee == mot:                                  #si egal au mot
                reponse = reponse_a_trouvee                             #reponse est complétée avec toutes les lettres
                score_partie = score_partie + (len(mot) - lettres_trouvees)           #maj du score
            elif lettre_proposee in lettre_incorrectes or lettre_proposee in reponse:
                print("Tu as déjà essayé ce caractère !\nLes caractères / mots que tu as déjà essayés et qui sont faux sont :")
                print(faux(lettre_incorrectes))
                dessin(compteur_erreurs)
                print("Le mot contient", len(mot), "caractères.")
                print(affichage(reponse))
            else:
                if lettre_proposee in reponse_a_trouvee:
                    for lettre in range(len(mot)):
                        if lettre_proposee == mot[lettre]:
                            reponse[lettre] = lettre_proposee
                            lettres_trouvees += 1
                    print("Oui, ce caractère est bien dans le mot.\nLes caractères / mots que tu as déjà essayés et qui sont faux sont :")
                    print(faux(lettre_incorrectes))
                    dessin(compteur_erreurs)
                    print("Le mot contient", len(mot), "caractères.")
                    print(affichage(reponse))
                elif lettre_proposee not in reponse_a_trouvee:
                    compteur_erreurs += 1
                    score_partie -= 1
                    lettre_incorrectes.append(lettre_proposee)
                    print("Et non, ce caractères n'est pas dans le mot à trouver !\nLes caractères / mots que tu as déjà essayés et qui sont faux sont :")
                    print(faux(lettre_incorrectes))
                    dessin(compteur_erreurs)
                    print("Le mot contient", len(mot), "caractères.")
                    print(affichage(reponse))
        else:
            lettre_incorrectes.append(lettre_proposee)
            compteur_erreurs += 1
            print("Ceci n'est pas un caractère valide ou le mot n'est pas celui qu'il faut que tu trouves !\nLes caractères / mots que tu as déjà essayés et qui sont faux sont :")
            print(faux(lettre_incorrectes))
            dessin(compteur_erreurs)
            print("Le mot contient", len(mot), "caractères.")
            print(affichage(reponse))
    score_total += score_partie
    if reponse == reponse_a_trouvee:
        print("Bravo ! 👏\nTu as trouvé 🎉, le mot était bien ", mot, ". 🍾 🥂\nTon score pour cette partie est de ", score_partie, " et ton score total est de ", score_total, " ! 🏆", sep = "")
    elif compteur_erreurs >= 11:
        dessin(compteur_erreurs)
        print("Perdu ! ☠ Tu as fait trop d'erreurs !\nLe mot qu'il fallait trouver était ", mot, ".\nTon score pour cette partie est de ", score_partie, " et ton score total est de ", score_total, " ! 🏆", sep = "")
    rejouer = str(input("Veux - tu rejouer ? "))
    rejouer = rejouer.lower()
print("Merci d'avoir joué au jeu du pendu, ton score totoal est de", score_total, "! 🏆\nÀ très vite ! 👋")