from bataille_navale import *

print("Let's go !")

jeu_ordi = grille(8)
tirs_ordi = grille(8)
jeu_nous = grille(8)
tirs_nous = grille(8)
touches_ordi = []
nb_touches_nous = 0
nb_coups_ordi = 0
nb_coups_nous = 0

print("Premièrement, il faut placer les bateaux !")
placement_bateau(jeu_nous, 0)
placement_bateau(jeu_ordi, 1)

possibilites_coups_ordi = coups_possibles(jeu_ordi)
random.shuffle(possibilites_coups_ordi)

print("Les bateaux sont maintenant placés, le jeu peut commencer.")
j = random.randint(0, 1)

while nb_touches_nous < 4 and len(touches_ordi) < 4:
    if j == 0:
        print("C'est au tour du joueur de tirer.")
        nb_touches_nous = tir_joueur(jeu_ordi, tirs_nous, nb_touches_nous)
        affichage(j, tirs_nous, jeu_nous)
        nb_coups_nous += 1
        j = 1
    else:
        print("C'est au tour de l'ordinateur de tirer.")
        touches_ordi = tir_ordi(jeu_nous, tirs_ordi, touches_ordi, possibilites_coups_ordi)
        affichage(j, tirs_nous, jeu_nous)
        j = 0
        nb_coups_ordi += 1
    print("--------------------------------------")

print("Coulé !")
if nb_touches_nous == 4:
    print("C'est le joueur qui remporte la partie en", nb_coups_nous, "coups. Bravo !")
else:
    print("C'est l'ordinateur qui remporte la partie en", nb_coups_ordi, "coups. Bravo !")