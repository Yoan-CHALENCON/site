import numpy
import random

def grille(cote):
    """Prend en entrée cote un int qui correspond à l'ordre de la matrice
    carrée que l'on souhaite créer
    Renvoie une matrice carrée nulle d'ordre cote"""
    assert type(cote) == int
    matrice = []
    for i in range(cote):
        ligne = []
        for j in range(cote):
            ligne.append(0)
        matrice.append(ligne)
    return matrice

def est_valide(val):
    """Prend en entrée une valeur de n'importe quel type
    Renvoie True si cette valeur est de type int ET est comprise entre 1 et 8,
    si ce n'est pas le cas, renvoie False"""
    if type(val) == int and val >= 1 and val <= 8:
        return True
    else:
        return False

def placement_bateau(matrice, joueur):
    """Prend en entrée une matrice qui ne contient aucun bateau ainsi que le
    joueur qui doit placer son bateau (0 pour le joueur et 1 pour l'ordinateur)
    Renvoie la matrice avec le bateau placé"""
    assert joueur == 0 or joueur == 1
    depart_g = None
    depart_h = None
    sens = None
    compt = 0
    if joueur == 0:
        while (sens != "H" and sens != "h") and (sens != "V" and sens != "v"):
            sens = input("Voulez - vous placer votre bateau dans le sens horizontal (H/h) ou dans le sens vertical (V/v) ?")
            if sens == "H" or sens == "h":
                while  compt == 0 or 1 < depart_g and depart_g > len(matrice) - 3 and 1 < depart_h and depart_h > len(matrice)-1:
                    compt = 1
                    while est_valide(depart_g) == False or est_valide(depart_h) == False:
                        depart_h = int(input("Entrez la valeur de la ligne"))
                        depart_g = int(input("Entrez la valeur la plus à gauche de votre bateau"))
            elif sens == "V"  or sens == "v":
                while  compt == 0 or 1 < depart_g and depart_g > len(matrice)-1 and 1 < depart_h and depart_h > len(matrice) - 3:
                    compt = 1
                    while est_valide(depart_g) == False or est_valide(depart_h) == False:
                        depart_h = int(input("Entrez la valeur de la ligne la plus haute du bateau"))
                        depart_g = int(input("Entrez la valeur de la colonne"))
    else:
        sens = random.choices(["V", "H"])
        if sens == "H":
            depart_h, depart_g = random.randint(1, len(matrice)-1), random.randint(1, len(matrice) - 4)
        else:
            depart_h, depart_g = random.randint(1, len(matrice) - 4), random.randint(1, len(matrice)-1)
    if sens == "H" or sens == "h":
        for i in range(4):
            matrice[depart_h-1][depart_g+i-1] = 2
    else:
        for i in range(4):
            matrice[depart_h+i-1][depart_g-1] = 2

def coups_possibles(matrice):
    """Prend en entrée une matrice nulle
    Renvoie la liste contenant toutes les coordonnées présentes dans la matrice
    en partant de 1 (et pas de 0 comme les ordinateurs)"""
    assert type(matrice) == list
    liste = []
    for i in range(1, len(matrice) + 1):
        for j in range(1, len(matrice) + 1):
            liste.append((i,j))
    return liste

def affichage(joueur, matrice_coups_effectues, matrice_recap_tirs_adv):
    """Prend en entrée le joueur qui vient de tirer, la matrice de tous les tirs
    qu'il a déjà effectué ainsi que le récapitulatif des tirs faits par son
    adversaire
    Affiche la matrice qui correspond au joueur concerné"""
    assert joueur == 0 or joueur == 1
    assert type(matrice_coups_effectues) == list
    assert type(matrice_recap_tirs_adv) == list
    if joueur == 0:
        print("Coups déjà effectués :", numpy.array(matrice_coups_effectues), sep ='\n')
    else:
        print("Voici un récapitulatif des tirs de l'ordinateur :", numpy.array(matrice_recap_tirs_adv), sep ='\n')

def tir_joueur(matrice_tir, matrice_visu, touches):
    """Prend en entrée la matrice sur laquelle le joueur tire (tirs joueur +
    bateau ordi) ainsi que celle où le joueur voit où il a déjà tiré (tirs
    joueur), touches correspond au nombre de fois où le joueur a touché le
    bateau de son adversaire
    Modifie les deux matrices en ajoutant le tir effectué et ajoute 1 au nombre
    de touches du joueur si le bateau de l'adversaire a été touché
    Renvoie le nombre de touches"""
    assert type(matrice_tir) == list
    assert type(matrice_visu) == list
    assert type(touches) == int
    tir_confirme = False
    ligne = None
    colonne = None
    while tir_confirme == False:
            while est_valide(ligne) == False:
                ligne = int(input("Ligne ?"))
            while est_valide(colonne) == False:
                colonne = int(input("Colonne ?"))
            position = (ligne, colonne)
            if matrice_visu[position[0] - 1][position[1] - 1] == 0:
                tir_confirme = True
            else:
                print("Tu as déjà tiré à cet endroit !")
                ligne = None
                colonne = None
    if matrice_tir[position[0] - 1][position[1] - 1] == 0:
        print("Plouf !")
        matrice_tir[position[0] - 1][position[1] - 1] = 1
        matrice_visu[position[0] - 1][position[1] - 1] = 1
    elif matrice_tir[position[0] - 1][position[1] - 1] == 2:
        print("Touché !")
        matrice_tir[position[0] - 1][position[1] - 1] = 3
        matrice_visu[position[0] - 1][position[1] - 1] = 3
        touches += 1
    return touches

def tir_ordi(matrice_tir, matrice_visu, liste_touches, tirs_possibles):
    """Prend en entrée la matrice sur laquelle l'ordinateur tire (tirs ordi +
    bateau joueur) ainsi que celle où l'ordinateur voit où il a déjà tiré (tirs
    ordi), liste_touches correspond aux positions des touches faites par l'ordi,
    tirs_posibles est la liste des positions où l'ordi n'a pas encore tiré
    Modifie les deux matrices en ajoutant le tir effectué et ajoute les
    positions à liste_touches si le bateau de l'adversaire est touché
    Renvoie listes_touches"""
    assert type(matrice_tir) == list
    assert type(matrice_visu) == list
    assert type(liste_touches) == list
    assert type(tirs_possibles) == list
    position = ()
    tir_confirme = False
    if len(liste_touches) == 1:
        coo = liste_touches[0]
        if (coo[0], coo[1]+1) in tirs_possibles:
            position = (coo[0], coo[1]+1)
        if (coo[0], coo[1]-1) in tirs_possibles:
            position = (coo[0], coo[1]-1)
        if (coo[0]+1, coo[1]) in tirs_possibles:
            position = (coo[0]+1, coo[1])
        if (coo[0]-1, coo[1]) in tirs_possibles:
            position = (coo[0]-1, coo[1])
    if len(liste_touches) == 2 or len(liste_touches) == 3:
        liste_touches.sort()
        coo_1 = liste_touches[0]
        if len(liste_touches) == 2:
            coo_2 = liste_touches[1]
        else:
            coo_2 = liste_touches[2]
        if coo_1[0] == coo_2[0]:
            if (coo_1[0], coo_2[1]+1) in tirs_possibles:
                position = (coo_1[0], coo_2[1]+1)
            if (coo_1[0], coo_2[1]-1) in tirs_possibles:
                position = (coo_1[0], coo_2[1]-1)
            if (coo_1[0], coo_1[1]+1) in tirs_possibles:
                position = (coo_1[0], coo_1[1]+1)
            if (coo_1[0], coo_1[1]-1) in tirs_possibles:
                position = (coo_1[0], coo_1[1]-1)
        elif coo_1[1] == coo_2[1]:
            if (coo_1[0]-1, coo_1[1]) in tirs_possibles:
                position = (coo_1[0]-1, coo_1[1])
            if (coo_1[0]+1, coo_1[1]) in tirs_possibles:
                position = (coo_1[0]+1, coo_1[1])
            if (coo_2[0]-1, coo_1[1]) in tirs_possibles:
                position = (coo_2[0]-1, coo_1[1])
            if (coo_2[0]+1, coo_1[1]) in tirs_possibles:
                position = (coo_2[0]+1, coo_1[1])
    if len(liste_touches) == 0:
        position = random.choice(tirs_possibles)
    compt = 0
    while tir_confirme == False:
        compt += 1
        if (position[0], position[1]) in tirs_possibles:
            tir_confirme = True
        else:
            position = random.choice(tirs_possibles)
        if compt == 10:
            input("Problème")
    print("L'ordinateur a joué en :", position)
    if matrice_tir[position[0] - 1][position[1] - 1] == 0:
        print("Plouf !")
        matrice_tir[position[0] - 1][position[1] - 1] = 1
        matrice_visu[position[0] - 1][position[1] - 1] = 1
    elif matrice_tir[position[0] - 1][position[1] - 1] == 2:
        print("Touché !")
        matrice_tir[position[0] - 1][position[1] - 1] = 3
        matrice_visu[position[0] - 1][position[1] - 1] = 3
        liste_touches.append(position)
    tirs_possibles.remove((position[0], position[1]))
    return liste_touches